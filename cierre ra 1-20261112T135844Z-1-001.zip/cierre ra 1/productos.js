const productos = [
    { id: 1, nombre: "PC Gamer RTX 4060", categoria: "pc", precio: 55000, img: "https://images.unsplash.com/photo-1587202372775-e229f172b9d7?w=400" },
    { id: 2, nombre: "Teclado Mecánico RGB", categoria: "perifericos", precio: 3500, img: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400" },
    { id: 3, nombre: "Mouse Gamer 16000 DPI", categoria: "perifericos", precio: 2200, img: "https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=400" },
    { id: 4, nombre: "Audífonos Surround 7.1", categoria: "perifericos", precio: 4100, img: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400" },
    { id: 5, nombre: "Mantenimiento Preventivo PC", categoria: "servicios", precio: 1500, img: "img 6.jpg" },
    { id: 6, nombre: "Instalación S.O. & Driver", categoria: "servicios", precio: 1000, img: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400" }
];

document.addEventListener("DOMContentLoaded", () => {
    renderProductos(productos);
    actualizarContadorCarrito();
});

function renderProductos(lista) {
    const grid = document.getElementById("grid-productos");
    if (!grid) return;
    grid.innerHTML = "";

    lista.forEach(prod => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <img src="${prod.img}" alt="${prod.nombre}">
            <h3>${prod.nombre}</h3>
            <p class="price">RD$ ${prod.precio.toLocaleString()}</p>
            <button class="btn" onclick="agregarAlCarrito(${prod.id})">Agregar al Carrito</button>
        `;
        grid.appendChild(card);
    });
}

function filtrarProductos(cat) {
    const botones = document.querySelectorAll(".filter-btn");
    botones.forEach(btn => btn.classList.remove("active"));
    if(event) event.target.classList.add("active");

    if (cat === "todos") {
        renderProductos(productos);
    } else {
        const filtrados = productos.filter(p => p.categoria === cat);
        renderProductos(filtrados);
    }
}

function agregarAlCarrito(id) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    const prod = productos.find(p => p.id === id);
    const existe = carrito.find(p => p.id === id);

    if (existe) {

        existe.cantidad = Number(existe.cantidad) + 1;
    } else {
        carrito.push({ ...prod, cantidad: 1 });
    }

    localStorage.setItem("carrito", JSON.stringify(carrito));
    
    actualizarContadorCarrito();
    
    alert(`¡${prod.nombre} fue agregado al carrito!`);
}

function actualizarContadorCarrito() {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    
    const totalItems = carrito.reduce((acc, item) => acc + (Number(item.cantidad) || 1), 0);
    
    const contador = document.getElementById("cart-count");
    if (contador) {
        contador.textContent = totalItems;
    }
}