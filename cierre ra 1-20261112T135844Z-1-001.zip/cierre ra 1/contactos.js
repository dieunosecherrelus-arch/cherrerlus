function validarFormulario(event) {
    event.preventDefault();
    const nombre = document.getElementById("nombre").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const direccion = document.getElementById("direccion").value.trim();
    const mensaje = document.getElementById("mensaje-estado");

    if (nombre === "" || correo === "" || direccion === "") {
        mensaje.style.color = "#ff4d4d";
        mensaje.textContent = "Por favor, completa todos los campos requeridos.";
        return false;
    }

    if (!correo.includes("@") || !correo.includes(".")) {
        mensaje.style.color = "#ff4d4d";
        mensaje.textContent = "Ingresa un correo electrónico válido.";
        return false;
    }

    mensaje.style.color = "#00ff88";
    mensaje.textContent = "¡Mensaje o Pedido enviado con éxito! Nos pondremos en contacto contigo.";
    document.getElementById("form-contacto").reset();
    return true;
}