document.addEventListener("DOMContentLoaded", () => {
    mostrarCarrito();
});

function mostrarCarrito() {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    const tbody = document.getElementById("carrito-body");
    const totalElem = document.getElementById("carrito-total");
    if (!tbody) return;

    tbody.innerHTML = "";
    let total = 0;

    if (carrito.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;">El carrito está vacío.</td></tr>`;
        totalElem.textContent = "RD$ 0";
        return;
    }

    carrito.forEach((item, index) => {
        const subtotal = item.precio * Number(item.cantidad);
        total += subtotal;

        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.nombre}</td>
            <td>RD$ ${item.precio.toLocaleString()}</td>
            <td>
                <input type="number" min="1" value="${item.cantidad}" onchange="cambiarCantidad(${index}, this.value)" style="width: 60px; background: #121218; color: #fff; border: 1px solid #7e22ce; padding: 4px; text-align: center; border-radius: 4px;">
            </td>
            <td>RD$ ${subtotal.toLocaleString()}</td>
            <td><button style="background:#ff4d4d; color:white; border:none; padding:6px 12px; cursor:pointer; border-radius:4px; font-weight:bold;" onclick="eliminarDelCarrito(${index})">X</button></td>
        `;
        tbody.appendChild(row);
    });

    totalElem.textContent = `RD$ ${total.toLocaleString()}`;
}

function cambiarCantidad(index, cant) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    carrito[index].cantidad = Math.max(1, parseInt(cant) || 1);
    localStorage.setItem("carrito", JSON.stringify(carrito));
    mostrarCarrito();
}

function eliminarDelCarrito(index) {
    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
    carrito.splice(index, 1);
    localStorage.setItem("carrito", JSON.stringify(carrito));
    mostrarCarrito();
}

function vaciarCarrito() {
    localStorage.removeItem("carrito");
    mostrarCarrito();
}